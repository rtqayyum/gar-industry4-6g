# GAR revision campaign

Status: NUMERICAL_CAMPAIGN_COMPLETE

Expected tasks: 12162; received: 12162; missing: 0; failed: 0.

Counts include pilot and calibration manifests. Missing production manifests: none.

Numerical completion does not establish that every reviewer comment is resolved. No automatic resubmission is performed.

| Study | Received | Complete | Provisioning rejected |
|---|---:|---:|---:|
| E1 | 3600 | 3600 | 0 |
| E2_CALIBRATION | 1152 | 1152 | 0 |
| E2_EVALUATION | 1680 | 1680 | 0 |
| E3 | 4560 | 4440 | 120 |
| E4 | 570 | 570 | 0 |
| E5_CONTROLLER_ONLY | 300 | 300 | 0 |
| E6_SERVICE_ABSTRACTION | 180 | 180 | 0 |
| PILOT | 120 | 120 | 0 |

Recovery source: /home/tariq.qayyum/gar-industry4-6g/results/revision/20261110T204141130477Z-cade4389. Imported preparation tasks: 1272. Original failed attempts remain in the source campaign.

## Open work

- gateway_restart: Controller outages are tested. Durable gateway restart recovery remains open.
- industrial_data: No independently measured industrial byte-arrival trace is claimed. Current generators are synthetic contracts.
- packet_service: Recorded packet evidence can be verified. A repaired live executor with a defensible service bound remains open.
- multihop: Supply-drop stress is a one-gateway abstraction, not a physical wireless or general multi-hop validation.
- manuscript: Integrate and independently review the proof and detailed algorithm, reconcile notation, references and every original review comment.

Paired effects resample whole independent seed blocks. Missing, failed and infeasible cases remain explicit. Peak and keep-calendar decisions coincide when the installed baseline calendar is constant; this is reported as equivalence, not extra independent evidence.
